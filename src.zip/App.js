import Route from './src/router/route';

export default function App() {
  return <Route/>
}

