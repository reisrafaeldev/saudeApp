export const clinicList = [
    {
      "nome": "Centro de Bem-Estar",
      "latitude": -21.7599676767131, 
      "longitude": -43.342890829712424,
    },
    {
      "nome": "Centro de Fisioterapia 1",
      "latitude": -21.75861133705354, 
      "longitude": -43.348414186005506
    },
    {
      "nome": "Secretaria Municipal de Saúde",
      "latitude": -21.75304182679375,
      "longitude":  -43.35257355712515
    },
    {
      "nome": "Centro Médico Público",
      "latitude": -21.76221362861192, 
      "longitude": -43.35487014240592
    },
    {
      "nome": "Centro de Fisioterapia 2",
      "latitude": -21.770336859886886, 
      "longitude": -43.34889013553488
    },
    {
      "nome": "Clínica Médica 1",
      "latitude": -21.771276716265813, 
      "longitude": -43.35669800454129
    },
    {
      "nome": "Centro Médico Público 2",
      "latitude": -21.745787139876487,
      "longitude":  -43.356693168052246
    },
    {
      "nome": "Centro de Fisioterapia 3",
      "latitude": -21.747939636653744, 
      "longitude": -43.3359221431703
    }
  ]
  